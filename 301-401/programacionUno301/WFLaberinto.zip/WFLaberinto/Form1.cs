﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFLaberinto
{
    public partial class Form1 : Form
    {
        System.Media.SoundPlayer startingSoundPlayer =  new System.Media.SoundPlayer(@"C:\\Windows\Media\Windows Print complete.wav");
        System.Media.SoundPlayer finishSoundPlayer = new System.Media.SoundPlayer(@"C:\\Windows\Media\tada.wav");
        System.Media.SoundPlayer TocarMuro = new System.Media.SoundPlayer(@"C:\Users\nehem\Downloads\mi_explosion_03_hpx.wav");
        public Form1()
        {
            InitializeComponent();
            MueveAlInicio();
        }

        private void lblMeta_MouseEnter(object sender, EventArgs e)
        {
            //ejecuta sonido y muestra un msj de felicitaciones y cierra el formulario
            finishSoundPlayer.Play();
            MessageBox.Show("¡Felicitaciones!","Ganó");
            MueveAlInicio();
        }
        /// <summary>
        /// ejecuta un sonido y entonces Mueve el apuntador 185 pixeles
        /// a la derecha y 335 pixeles hacia abajo del punto inicial del juego 
        /// </summary>
        private void MueveAlInicio()
        {
            Point startingPoint = panel1.Location;
            startingPoint.Offset(185, 335);
            Cursor.Position = PointToScreen(startingPoint);
            startingSoundPlayer.Play();
        }

        private void muro_MouseEnter(object sender, EventArgs e)
        {
            //cuando el apuntador del mouse toca un muro o se introduce a el
            //llama al metodo TocarMuro y reproduce un sonido 
            TocarMuro.Play();
            Point startingPoint = panel1.Location;
            startingPoint.Offset(185, 335);
            Cursor.Position = PointToScreen(startingPoint);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_DoubleClick(object sender, EventArgs e)
        {
            Close();
        }
    }
}
