import { Fragment, useState } from "react";
import Header from "./Componentes/Header";
import Formulario from "./Componentes/Formulario";
import Mensaje from "./Componentes/Mensaje";
import Resultado from "./Componentes/Resultado";
import Spinner from "./Componentes/Spinner";
import "./index.css";

function App() {

  const [cantidad, guardarCantidad] = useState(0);
  const [plazo, guardarPlazo] = useState("");
  const [total, guardarTotal] = useState(0);
  const [cargando, guardarCargando] = useState(false)

    let componente;

  if(cargando){
    componente = <Spinner/>
  }
  else if (total === 0) {
    componente = <Mensaje />;
  } else {
    componente = <Resultado total={total} plazo={plazo} cantidad={cantidad} />;
  }

  return (
    <Fragment>
      <h1> <span>Jesus Nehemias Contreras Barrera</span></h1>
      <Header titulo="Cotizador de prestamos" />

      <div className="container">
        <Formulario
          cantidad={cantidad}
          guardarCantidad={guardarCantidad}
          plazo={plazo}
          guardarPlazo={guardarPlazo}
          total={total}
          guardarTotal={guardarTotal}
          guardarCargando = {guardarCargando}
        />
      </div>

      <div className="mensajes">
        {componente}
      </div>
    </Fragment>
  );
}

export default App;
