// Tarea 2: Simulador de Chateo
// Archivo: simuladorChat.js

// 1. Conversación coherente entre dos participantes (mínimo 4 frases)
const frasesPersona1 = [
    "¡Hola! ¿Cómo estás? Tenía rato sin saber de ti.",
    "Pues estos días he estado algo ocupado con la escuela y el trabajo.",
    "Ah, por cierto, ¿te acuerdas del proyecto que te mencioné? Por fin lo terminé.",
    "Podríamos celebrarlo después, ¿no? Se me antoja salir a comer.",
    "¿Y tú qué tal? ¿Qué planes tienes para esta semana?",
    "Por cierto, encontré una serie buenísima, te la quiero recomendar."
];

const frasesPersona2 = [
    "¡Hola! Todo bien, gracias. Sí, ya tenía días sin saber de ti.",
    "¡Te creo! Yo también he tenido semanas pesadas.",
    "¡Qué buena noticia! Me alegra que lo hayas terminado.",
    "Sí, estaría genial salir a comer. ¿Qué se te antoja?",
    "Esta semana quiero adelantar unas cosas, pero tengo tiempo libre por las tardes.",
    "Uy, pásamela. Justo estoy buscando algo nuevo para ver."
];



// 2. Elementos del DOM
const nextMessageBtn = document.getElementById('next-message-btn');
const chatBox = document.getElementById('chat-box');

// Variables de estado
let turno = 0; // 0 para Persona 1, 1 para Persona 2
let indicesUsados1 = []; // Para evitar repetir frases seguidas de P1
let indicesUsados2 = []; // Para evitar repetir frases seguidas de P2

// 3. Función auxiliar para obtener un valor aleatorio no repetido de un array
function randomValueFromArray(array, indicesUsados) {
    let random;
    do {
        random = Math.floor(Math.random() * array.length);
    } while (indicesUsados.includes(random));
    
    // Si el array de usados alcanza su tamaño, se limpia para permitir repeticiones futuras
    if (indicesUsados.length >= array.length) {
        indicesUsados.shift(); // Elimina el más antiguo
    }
    
    indicesUsados.push(random); // Agrega el nuevo índice usado
    return array[random];
}

// 4. Función principal para generar y mostrar el siguiente mensaje
function generarSiguienteMensaje() {
    let mensaje;
    let claseCSS;
    let arrayFrases;
    let indicesUsados;

    if (turno === 0) {
        // Es el turno de Persona 1
        arrayFrases = frasesPersona1;
        indicesUsados = indicesUsados1;
        mensaje = randomValueFromArray(arrayFrases, indicesUsados);
        claseCSS = 'person1';
        turno = 1; // Cambiar turno a Persona 2
    } else {
        // Es el turno de Persona 2
        arrayFrases = frasesPersona2;
        indicesUsados = indicesUsados2;
        mensaje = randomValueFromArray(arrayFrases, indicesUsados);
        claseCSS = 'person2';
        turno = 0; // Cambiar turno a Persona 1
    }

    // 5. Crear y añadir el elemento del mensaje al chat-box
    const p = document.createElement('p');
    p.classList.add('message', claseCSS);
    p.textContent = mensaje;
    
    chatBox.appendChild(p);

    // 6. Desplazar el scroll al final para ver el nuevo mensaje
    chatBox.scrollTop = chatBox.scrollHeight;
}

// 7. Event Listener para el botón
nextMessageBtn.addEventListener('click', generarSiguienteMensaje);

// Opcional: Generar un mensaje inicial al cargar la página.
// generarSiguienteMensaje();