import React from "react";

function App(props) {
  return (
    <div className="todoapp stack-large">
      <h1>TodoMatic</h1>
      <form className="stack-small">
        <h2 className="label-wrapper">
          <p>Jesus Nehemias Contreras Barrera</p>
          <label htmlFor="new-todo-input" className="label__lg">
            ¿Qué tareas hay que hacer?
          </label>
        </h2>
        <div className="todo-row">
          <input
            type="text"
            id="new-todo-input"
            className="input input__lg"
            name="text"
            autoComplete="off"
            style={{ flex: '1' }}
          />
          <button type="submit" className="btn btn__primary">
            Agregar
          </button>
        </div>
      </form>
      <div className="filters btn-group stack-exception">
        <button type="button" className="btn toggle-btn" aria-pressed="true">
          <span className="visually-hidden">Mostrar </span>
          <span>Todas</span>
          <span className="visually-hidden"> las tareas</span>
        </button>
        <button type="button" className="btn toggle-btn" aria-pressed="false">
          <span className="visually-hidden">Mostrar </span>
          <span>Activas</span>
          <span className="visually-hidden"> las tareas</span>
        </button>
        <button type="button" className="btn toggle-btn" aria-pressed="false">
          <span className="visually-hidden">Mostrar </span>
          <span>Completadas</span>
          <span className="visually-hidden"> las tareas</span>
        </button>
      </div>
      <h2 id="list-heading">3 tareas restantes</h2>
      <ul
        role="list"
        className="todo-list stack-large stack-exception"
        aria-labelledby="list-heading"
      >
        <li className="todo">
          <div className="todo-row">
            <div className="c-cb">
              <input id="todo-0" type="checkbox" defaultChecked />
              <label className="todo-label" htmlFor="todo-0">
                Comer
              </label>
            </div>
            <div className="btn-group">
              <button type="button" className="btn">
                Editar <span className="visually-hidden">Comer</span>
              </button>
              <button type="button" className="btn btn__danger">
                Eliminar <span className="visually-hidden">Comer</span>
              </button>
            </div>
          </div>
        </li>
        <li className="todo">
          <div className="todo-row">
            <div className="c-cb">
              <input id="todo-1" type="checkbox" />
              <label className="todo-label" htmlFor="todo-1">
                Dormir
              </label>
            </div>
            <div className="btn-group">
              <button type="button" className="btn">
                Editar <span className="visually-hidden">Dormir</span>
              </button>
              <button type="button" className="btn btn__danger">
                Eliminar <span className="visually-hidden">Dormir</span>
              </button>
            </div>
          </div>
        </li>
        <li className="todo">
          <div className="todo-row">
            <div className="c-cb">
              <input id="todo-2" type="checkbox" />
              <label className="todo-label" htmlFor="todo-2">
                Repetir
              </label>
            </div>
            <div className="btn-group">
              <button type="button" className="btn">
                Editar <span className="visually-hidden">Repetir</span>
              </button>
              <button type="button" className="btn btn__danger">
                Eliminar <span className="visually-hidden">Repetir</span>
              </button>
            </div>
          </div>
        </li>
      </ul>
    </div>
  );
}

export default App;