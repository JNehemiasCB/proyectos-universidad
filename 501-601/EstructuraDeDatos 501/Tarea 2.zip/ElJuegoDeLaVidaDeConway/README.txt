using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ElJuegoDeLaVidaDeConway
{
    internal class Program
    {

        static void Main(string[] args)
        {

            // Crear título y convertirlo a mayúsculas
            string texto = "El juego de la vida de Conway";
            string titulo = texto.ToUpper();
            Console.WriteLine(titulo);

            // Preguntar al usuario cuántas generaciones quiere observar
            Console.Write("¿Cuántas generaciones quieres observar? ");
            int generaciones = Convert.ToInt32(Console.ReadLine()); // Convertir entrada a entero

            // Crear objeto Random para generar valores aleatorios
            Random Taquito = new Random();

            // Definir tamaño de la matriz cuadrada
            int tamaño = 5;
            bool[,] rejilla = new bool[tamaño, tamaño]; // true = viva, false = muerta

            // Símbolos para mostrar la rejilla en consola
            string Vivo = " + ";   // Celda viva
            string Vacio = "   ";  // Celda muerta

            // Inicializar la rejilla aleatoriamente
            for (int i = 0; i < tamaño; i++)
                for (int j = 0; j < tamaño; j++)
                    rejilla[i, j] = Taquito.Next(0, 2) == 1; // 50% probabilidad de vivo

            // Bucle principal de generaciones
            for (int g = 0; g < generaciones; g++)
            {
                Console.WriteLine("");
                Console.WriteLine($"Generación {g + 1}"); // Mostrar número de generación

                // Mostrar la rejilla en consola
                Mostrar_Rejilla(rejilla, Vivo, Vacio);

                // Crear una nueva matriz para calcular la siguiente generación
                bool[,] Nueva_Rejilla = new bool[tamaño, tamaño];

                // Recorrer cada celda para aplicar las reglas de Conway
                for (int i = 0; i < tamaño; i++)
                    for (int j = 0; j < tamaño; j++)
                    {
                        int vecinos = Contar_Vecinos(rejilla, i, j); // Contar vecinos vivos

                        // Aplicar reglas:
                        // Celda viva sobrevive con 2 o 3 vecinos
                        // Celda viva muere si <2 o >3 vecinos (soledad o hacinamiento)
                        // Celda muerta nace si tiene exactamente 3 vecinos
                        Nueva_Rejilla[i, j] = (rejilla[i, j] && (vecinos == 2 || vecinos == 3))
                                              || (!rejilla[i, j] && vecinos == 3);
                    }

                // Actualizar la rejilla para la siguiente generación
                rejilla = Nueva_Rejilla;

                Thread.Sleep(600); // Pausa de 600 ms para ver la animación
            }

            // Mensaje al finalizar la simulación
            Console.Write("");
            Console.WriteLine("Simulación terminada.");
            Console.WriteLine("Presione enter para salir...");
            Console.ReadLine();
        }

        // Método para mostrar la rejilla en consola
        static void Mostrar_Rejilla(bool[,] rejilla, string Vivo, string Vacio)
        {
            int filas = rejilla.GetLength(0);     // Número de filas
            int columnas = rejilla.GetLength(1);  // Número de columnas

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                    Console.Write(rejilla[i, j] ? Vivo : Vacio); // Mostrar celda viva o muerta
                Console.WriteLine(); // Salto de línea al final de cada fila
            }
        }

        // Función para contar vecinos vivos de una celda
        static int Contar_Vecinos(bool[,] rejilla, int fila, int columna)
        {
            int contador = 0; // Inicializar contador de vecinos
            int filas = rejilla.GetLength(0);
            int columnas = rejilla.GetLength(1);

            // Recorrer las 8 posiciones alrededor de la celda
            for (int di = -1; di <= 1; di++)
                for (int dj = -1; dj <= 1; dj++)
                {
                    if (di == 0 && dj == 0) continue; // Saltar la propia celda

                    int nuevaFila = fila + di;
                    int nuevaColumna = columna + dj;

                    // Comprobar límites de la matriz
                    if (nuevaFila >= 0 && nuevaFila < filas &&
                        nuevaColumna >= 0 && nuevaColumna < columnas &&
                        rejilla[nuevaFila, nuevaColumna]) // Si el vecino está vivo
                    {
                        contador++; // Contar vecino vivo
                    }
                }

            return contador; // Devolver número total de vecinos vivos
        }
    }
}